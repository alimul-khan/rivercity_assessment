# Interview KiCad Project



## Getting started

If you do not already, please download KiCad. KiCad is free, and can be found here: https://www.kicad.org/download/
This project was created with version 7, but as long as you download a version >= 7 this should work no problem. 

If you need to view the documentation for KiCad, you can find it here: https://docs.kicad.org/

## Instructions
Included in this directory, is a KiCad project that includes a very simple board with only a few components & their datasheets. (MCU, temperature sensor, antenna and power supply). 
This project has been intentionally given mistakes. Your task is to find all that you can and list what is wrong and what you would change. 

**Important**: You are not required to make the changes to correct the mistakes, however feel free if you want to.


## Submission
Once you have found all the mistakes, simply write the mistakes/corrections in a document and upload it to a git repository along with your firmware assessment. If you choose to make the changes in the project as well, please upload the KiCad project in this repository as well. If you have any questions during this assessment, feel free to reach out to riley@rivercityinnovations.ca.

Good luck! 