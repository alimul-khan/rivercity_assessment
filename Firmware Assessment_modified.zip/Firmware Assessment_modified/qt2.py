# Define constants for debug levels
DEBUG = 0
STAGING = 1
QA = 2
PRODUCTION = 3

# Set current debug level
Current_debug_level = DEBUG
# Current_debug_level = STAGING
# Current_debug_level = QA
# Current_debug_level = PRODUCTION

# Define debug print function
def debug_print(debug_level, message):
    if Current_debug_level >= debug_level:
        print(message)

# Test the debug print function
debug_print(PRODUCTION, "Only appears when debug_level=PRODUCTION")
debug_print(QA, "Only appears when debug_level>=QA")
debug_print(STAGING, "Only appears when debug_level>=STAGING")
