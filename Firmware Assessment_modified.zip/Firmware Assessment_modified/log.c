/*
 * my_log.c
 * 
 * Author: Alimul Haque Khan
 * Date: October 15, 2024
 * 
 * Description:
 * This file implements the log function to print messages based on the log level.
 * 
 * License:XYZ
*/

#include <stdio.h>
#include "log.h"

// Set the current log level
// #define CURRENT_LOG_LEVEL OFF
// #define CURRENT_LOG_LEVEL ERROR
// #define CURRENT_LOG_LEVEL INFO
// #define CURRENT_LOG_LEVEL DEBUG
#define CURRENT_LOG_LEVEL TRACE

// Note: I prefer to include additional context such as 'current_time':'file_name:line_number:message' 
// in the log message format for better debugging. However, for simplicity in this 
// assessment, only the 'message' is included.
void log_message(int log_level, const char *message) {
    if (CURRENT_LOG_LEVEL >= log_level) {
        printf("%s\n", message);
    }
}
