# Define constants for log levels
OFF = 0          # Production: No log messages
ERROR = 1        # Critical messages only
INFO = 2         # Key events and status updates
DEBUG = 3        # Detailed debugging messages
TRACE = 4        # All messages for in-depth testing

# Set current log level
# Current_log_level = OFF
# Current_log_level = ERROR
# Current_log_level = INFO
# Current_log_level = DEBUG
Current_log_level = TRACE

# Define log function
def log_message(log_level, message):
    if Current_log_level >= log_level:
        print(message)

# Test the log function with different levels
log_message(TRACE, "This message appears only in TRACE mode.")
log_message(DEBUG, "This message appears in DEBUG and higher levels.")
log_message(INFO, "This message appears in INFO and higher levels.")
log_message(ERROR, "This message appears in ERROR and higher levels.")
