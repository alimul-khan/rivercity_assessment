/*
 * main.c
 * 
 * Author: Alimul Haque Khan
 * Date: October 15, 2024
 * 
 * Description:
 * This is the main entry point of the program. It 
 * simulates interaction with an I2C sensor as part of the Rivercity Innovations 
 * Interview Firmware Assessment. The main function ensures the correct operation of 
 * the sensor through steps like sensor detection, waking up, measuring temperature 
 * and humidity, and putting the sensor to sleep in a continuous loop.
 * 
 * License: XYZ
 */

#include <stdio.h>
#include <unistd.h>  // For sleep function
#include "sensor.h"   // Include the sensor driver
#include "log.h"


// Step 1: Check if the sensor is detected
uint8_t step1() {
    if (shtc3_check_id() != 0) {
        log_message(ERROR, "Error: Sensor not detected.\n");

        
        return 1;  // Failure
    }
    log_message(INFO, "Sensor detected successfully!");

    return 0;  // Success
}

// Step 2: Wake up the sensor
uint8_t step2() {
    if (shtc3_wake() != 0) {
        log_message(ERROR, "Error: Failed to wake up the sensor.\n");

        return 1;  // Failure
    }
    log_message(INFO, "Sensor woken up.\n");
    
    return 0;  // Success
}

// Step 3: Measure temperature and humidity
uint8_t step3() {
    float temperature, humidity;
    if (shtc3_measure(&temperature, &humidity) == 0) {
        char message[100]; 
        snprintf(message, sizeof(message), "Temperature: %.1f°C, Humidity: %.1f%%", temperature, humidity);
        log_message(DEBUG, message);
        return 0;  // Success
    } else {
        log_message(ERROR, "Error: Measurement failed.\n");
        return 1;  // Failure
    }
}

// Step 4: Put the sensor to sleep
uint8_t step4() {
    if (shtc3_sleep() != 0) {
        log_message(ERROR, "Error: Failed to put the sensor to sleep.\n");

        return 1;  // Failure
    }
    log_message(INFO, "Sensor is now in sleep mode.");

    return 0;  // Success
}

int main() {

        // Test the log function with different levels
    log_message(TRACE, "This message appears only in TRACE mode.");
    log_message(DEBUG, "This message appears in DEBUG and higher levels.");
    log_message(INFO, "This message appears in INFO and higher levels.");
    log_message(ERROR, "This message appears in ERROR and higher levels.");

    // Step 1: Check if the sensor is detected
    if (step1() != 0) {
        return 1;  // Exit if sensor is not found
    }

    // Infinite loop to simulate continuous sensor operation
    while (1) {
        // Step 2: Wake the sensor
        if (step2() != 0) {
            continue;  // Retry if wake-up fails
        }

        // Step 3: Measure temperature and humidity
        if (step3() != 0) {
            continue;  // Retry if measurement fails
        }

        // Step 4: Put the sensor to sleep
        if (step4() != 0) {
            continue;  // Retry if sleep fails
        }

        // Wait 10 seconds before the next iteration
        sleep(10);
    }

    return 0;  // Program should never reach this point
}
