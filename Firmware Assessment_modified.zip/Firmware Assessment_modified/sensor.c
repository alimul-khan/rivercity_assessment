/*
 * sensor.c
 * 
 * Author: Alimul Haque Khan
 * Date: October 15, 2024
 * 
 * Description:
 * This file implements functions for interfacing with the SHTC3 sensor, 
 * including checking sensor communication, waking up the sensor, 
 * taking measurements, and putting the sensor to sleep.
 * 
 * License: XYZ
 */


#include "sensor.h"
#include "helperFunc.h"  // For I2C communication functions
#include <stdio.h>

// Function to check if the sensor is communicating correctly by reading the ID register
uint8_t shtc3_check_id() {
    uint8_t command[2] = {CMD_READ_ID >> 8, CMD_READ_ID & 0xFF};
    uint8_t id[2];  // Buffer to store the returned ID

    // Write the Read ID command
    I2cWriteBuffer(SENSOR_ADDRESS, command, 2);

    // Read the ID from the sensor
    I2cReadBuffer(SENSOR_ADDRESS, id, 2);

    // Verify if the ID matches expected values
    if (id[0] == 0x11 && id[1] == 0x22) {
        return 0;  // Success
    } else {
        return 1;  // Failure
    }
}

// Function to wake the sensor from sleep mode
uint8_t shtc3_wake() {
    uint8_t command[2] = {CMD_WAKE >> 8, CMD_WAKE & 0xFF};

    // Send the wake-up command via I2C
    return I2cWriteBuffer(SENSOR_ADDRESS, command, 2);
}


// Function to take temperature and humidity measurements
uint8_t shtc3_measure(float *temperature, float *humidity) {
    uint8_t command[2] = {CMD_MEASURE >> 8, CMD_MEASURE & 0xFF};
    uint8_t data[4];  // Buffer to store measurement data

    // Send the measurement command
    I2cWriteBuffer(SENSOR_ADDRESS, command, 2);

    // Read the measurement results from the sensor
    I2cReadBuffer(SENSOR_ADDRESS, data, 4);

    // Convert raw data to temperature in °C
    *temperature = ((data[0] << 8) | data[1]) * 175.0 / 65535.0 - 45.0;

    // Convert raw data to humidity in %RH
    *humidity = ((data[2] << 8) | data[3]) * 100.0 / 65535.0;

    return 0;  // Success
}


// Function to put the sensor into sleep mode
uint8_t shtc3_sleep() {
    uint8_t command[2] = {CMD_SLEEP >> 8, CMD_SLEEP & 0xFF};

    // Send the sleep command via I2C
    return I2cWriteBuffer(SENSOR_ADDRESS, command, 2);
}
