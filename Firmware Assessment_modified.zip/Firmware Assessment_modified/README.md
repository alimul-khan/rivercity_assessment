# Interview Firmware Assessment

## Getting started

Welcome to the Rivercity Innovations Firmware Assessment! 
In this project, you will write an example firmware driver along with some main code to simulate working with an embedded system.
This will allow the Rivercity team to evaluate your C code writing abilities and creativity.

## Objective

Your task is to write a simple firmware driver to simulate the communication of an I2C sensor & an MCU.
You will not need to compile these files in order for this assessment to be completed (see testing instructions below).
We simply want to see your ability to write in embedded C, your creativity, & your attention to detail.

## Instructions

You will see 6 files in this folder. 
- sensor.c
- sensor.h
- main.c
- main.h
- helperFunc.c
- helperFunc.h

### Step 1 - Firmware Driver:
Using the included datasheet for a temperature & humidity sensor, write a firmware driver for the included peripheral to do the following actions:

- Setup the sensor.h file with all of your definitions, function prototypes, and whatever you deem neccessary for the proper sensor operation.
- Write your driver code in sensor.c to give the temperature sensor the following functionality.
    - Check the sensors ID number to verify correct communication/operation
    - Wake function to bring the sensor out of sleep mode
    - Sleep function to put the sensor into sleep mode
    - Measurement function to obtain measurement values from the sensor
        - Please use a normal measurement, temperature first, with clock stretching enabled.
        - **For this assessment, we will ignore the CRC checksum in the measurement to make things simple. So assume that the return buffer does not include the extra byte for each piece of telemetry.** 
    - All functions should return a success status (0) or a failed status (1).

#### Provided Code:
You have some pre-written functions to work with for the I2C communication. See the function prototypes below.

**Write data buffer to the I2C device**
- [IN] deviceAddr       device address
- [IN] buffer           data buffer to write
- [IN] size             number of bytes to write

uint8_t I2cWriteBuffer( uint8_t deviceAddr, uint8_t *buffer, uint16_t size );


**Read data buffer from the I2C device**
- [IN] deviceAddr       device address
- [OUT] buffer          data buffer to read
- [IN] size             number of data bytes to read

uint8_t I2cReadBuffer( uint8_t deviceAddr, uint8_t *buffer, uint16_t size );

You will find the function definitions in the helperFunc.c file. You will need to use them to complete the driver. Since you won't have actual hardware to test this, the functions provided to you will utilize printf to show what you inputted in the case of the write function and in the case of the read function, has hardcoded/dummy values for the data you will need to "read" from the device.

### Step 2 - Main function:
Once you have written the firmware driver, write a main application code function called main() that will execute some function calls, simulating the operation of a micro controller. 

**The main program should have the following functionality:** 

- Begin by ensuring you are working with the correct device and ensuring communication can be established with the temperature & humidity sensor. (In a real world scenario there will be multiple I2C devices connected to the MCU so it is important to check that the peripheral can communicate)
- Next, write some code that will run infinitely and do the following.
    - Wake up the sensor
    - Take a measurement
        - Make sure to convert the temperature & humidity to °C & %, rounded to the nearest tenth (0.1)
    - Put the sensor to sleep
    - Wait 10 seconds
    - Repeat

### Step 3 - Testing: 
Your final step will be to test the functionality of your code. It is recommended to use https://www.onlinegdb.com/online_c_compiler to do this. This is a free online C compiler which will be able to execute your code if you have done it properly. Since this is an online compiler that is using a Linux system you will be able to utilize some standard C libaries that you may otherwise not be able to use in a real hardware environment. 

For example, when you want to make the program wait, use the sleep() function provided by the <unistd.h> library. This will be necessary since we do not have access to hardware timers in this environment.

Print out all required values from the previous instructions & whatever you feel necessary to provide good context of what is happening. 

## Submission
When you have completed all of the necessary steps, please upload your code to a git repository along with your hardware assessment so that we can review it. If you have any questions during this assessment, feel free to reach out to riley@rivercityinnovations.ca.

Good Luck! 