/*
 * my_log.h
 * 
 * Author: Alimul Haque Khan
 * Date: October 15, 2024
 * 
 * Description:
 * This header file defines the log levels and declares the log function.
 * 
 * License: XYZ
 
 */


#ifndef LOG_H
#define LOG_H

// Define constants for log levels
#define OFF 0     // Production: No log messages
#define ERROR 1   // Critical messages only
#define INFO 2    // Key events and status updates
#define DEBUG 3   // Detailed debugging messages
#define TRACE 4   // All messages for in-depth testing

// Declare the log function
void log_message(int log_level, const char *message);

#endif // LOG_H
