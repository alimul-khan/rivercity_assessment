/*
 * sensor.h
 * 
 * Author: Alimul Haque Khan
 * Date: October 15, 2024
 * 
 * Description:
 * This header file defines the I2C address, command codes, and function prototypes 
 * for interfacing with the SHTC3 sensor.
 * 
 * License: XYZ
 */

 
#ifndef SENSOR_H
#define SENSOR_H

#include <stdint.h>

// Sensor I2C Address
#define SENSOR_ADDRESS 0x70  // I2C device address of the SHTC3 sensor

// Command Codes (from the datasheet)
#define CMD_READ_ID 0xEFC8   // Read sensor ID command
#define CMD_WAKE 0x3517      // Wake-up command
#define CMD_MEASURE 0x7CA2   // Measure temperature first, clock stretching enabled
#define CMD_SLEEP 0xB098     // Sleep command

// Function Prototypes
uint8_t shtc3_check_id();        // Verify communication with the sensor
uint8_t shtc3_wake();            // Wake up the sensor
uint8_t shtc3_measure(float *temperature, float *humidity);  // Take measurement
uint8_t shtc3_sleep();           // Put the sensor to sleep

#endif // SENSOR_H
